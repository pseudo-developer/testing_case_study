from pyspark.sql import SparkSession

# Initialize SparkSession with Delta Lake support
spark = (
    SparkSession.builder
    .appName("Test")
    .getOrCreate()
)

df = (
    spark.read.format("csv")
    .option('header', True)
    .load(r"C:\Users\kumar.ankit2\Downloads\new_case_study\Data\Charges_use.csv")
)
# df1 = spark.read.format("csv").option('header', True).load("C:\\Users\\kumar.ankit2\\Desktop\\Charges_use.csv")

df.show(5)

df.createOrReplaceTempView('ankit')
spark.sql("select *, current_date() from ankit").show()

# df.write.format("delta").saveAsTable("test_table")
# df.write.format("delta").mode("overwrite").save(r"C:\Users\kumar.ankit2\Desktop\delta_table")
# df.write.format("delta").mode("overwrite").save(r"C:\Users\kumar.ankit2\Desktop\delta_table")




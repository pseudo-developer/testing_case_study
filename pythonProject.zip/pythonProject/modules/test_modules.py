############## LEARN WHAT/HOW to IMPORT as MODULES/PACKAGES ################

## What to import in this file : # All external imports needed for test_modules.py module only. Such that wherever the classes/functions from test_modules.py module are called, they work as expected and never break.

## The hierarchy should be like:
#1. All EXTERNAL imports
#2. All CUSTOM imports
#3. All built-in python/spark imports

# All external imports
from pyspark.sql import SparkSession  ## works only if pyspark is installed. Check "requirements.txt"

# All custom imports

# All built in imports

################## MODULES/PACKAGES ENDS ###################################

class SetSession:
    def __init__(self, appname):
        self.appname = appname

    def getSparkSession(self):
        # Initialize SparkSession with Delta Lake support
        spark = (
            SparkSession.builder
            .appName(self.appname)
            .getOrCreate()
        )
        return spark


class Ankit:
    def check_print(self,a,b):
        print("Class function check_print's output" ,a,' ',b)

    def print_sum(self,a,b):
        print("Class function print_sum's output, a and b after sum is :" ,a+b)


# The function accepts a parameter but doesn't use it inside the function
def normal_def_function_to_import(name=None):
    print(f"The normal def function is being called, function name: 'normal_def_function_to_import'")
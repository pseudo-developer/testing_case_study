# All external imports
from pyspark.sql import SparkSession  ## works only if pyspark is installed. Check "requirements.txt". How to install from requirements.txt file "pip install -r /path/to/requirements.txt"

# All custom imports

# All built in imports
import json

## REQUIREMENTS.txt - How to create:
#1, Once you are done with all packages imports in the virtual env, then just


class InitializeSession:
    def __init__(self, appname):
        self.appname = appname

    def getSparkSession(self):
        # Initialize SparkSession with Delta Lake support
        spark = (
            SparkSession.builder
            .appName(self.appname)
            .getOrCreate()
        )
        return spark



class read_files_and_config:
    def __init__(self):
        pass

    def read_config(self, path_to_config: str) -> dict:
        """ Reads a JSON config file containing paths.
        Args:
            path_to_config (str): The path to the JSON config file.

        Returns:
            dict: A dictionary containing the parsed configuration data.
        """
        with open(path_to_config, "r") as f:
            config_data = json.load(f)
        return config_data

    def readcsv(self, spark: SparkSession, path_to_source: str):
        """ Reads a CSV file into a DataFrame.
        Args:
            path_to_source (str): The path to the CSV file.
            spark (pyspark.sql.SparkSession): A SparkSession instance.

        Returns:
            pyspark.sql.DataFrame: The DataFrame containing the CSV data.
        """
        df_csv = spark.read.format("csv").option('header', True).load(path_to_source)
        return df_csv



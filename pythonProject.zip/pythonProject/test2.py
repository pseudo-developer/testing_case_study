# from pyspark.sql import SparkSession
#
# # Initialize the Spark session
# spark = SparkSession.builder.appName("TempTableExample").getOrCreate()
#
# # Sample data
# data = [("John", 30), ("Jane", 25), ("Mike", 35)]
# columns = ["Name", "Age"]
#
# # Create a DataFrame
# df = spark.createDataFrame(data, columns)
#
# df.show()

# Create a temporary table (view)
# df.createOrReplaceTempView("people")
#
# # Query the table using Spark SQL
# result = spark.sql("SELECT * FROM people")
#
# # Show the result
# result.show()



###################################


from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, IntegerType
from pyspark.sql.functions import *

# Initialize SparkSession
spark = SparkSession.builder.appName("Test").getOrCreate()

# Sample data
data = [("John", 30), ("Jane", 25), ("Mike", 35)]
columns = ["Name", "Age"]

# Define schema
schema = StructType([
    StructField("Name", StringType(), True),
    StructField("Age", IntegerType(), True)
])

# Create DataFrame with specified schema
df = spark.createDataFrame(data, schema)

df.show()





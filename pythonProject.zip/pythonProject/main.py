from modules.test_modules import SetSession, Ankit, normal_def_function_to_import


if __name__ == "__main__":
    session = SetSession("MyApp")
    spark = session.getSparkSession()

    print("Spark version is :", spark.version)

    # Create an instance of the Ankit class (imported from "modules") and use its methods
    ankit = Ankit()
    ankit.check_print(10, 20)
    ankit.print_sum(10, 20)

    print("*********************************")
    normal_def_function_to_import()


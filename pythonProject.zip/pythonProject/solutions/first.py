# All custom imports
from modules.utils import InitializeSession, read_files_and_config

# All built in imports


raw_file_name = 'Charges_use'

if __name__ == "__main__":
    try:
        session = InitializeSession("MyApp")
        spark = session.getSparkSession()
        print("Spark version is :", spark.version)

        # Read config data:
        config_path = '../config/json_config.json'  # Replace with your config file path
        read_json_config = read_files_and_config()
        config_dict = read_json_config.read_config(config_path)
        print("printing config below:::")
        print(config_dict)
        print("config ends")

        input_file_path = config_dict['files'][raw_file_name]['input_file_path']
        output_file_path = config_dict['files'][raw_file_name]['output_file_path']
        print(input_file_path,'\n')

        print("\nStart reading raw csv file")
        read_csv_from_source = read_files_and_config()
        df = read_csv_from_source.readcsv(spark, input_file_path)
        print(f"file {raw_file_name} at path {input_file_path} read successfully. Printing below 5 rows only:")

        df.show(5)

    except Exception as e:  # Catch any exception
        print("An error occurred:", e)
        # raise e


